package testPackage;

public class BubbleSort {
	
	static int[] a = {5,1,7,3,8,2,6,9,4,0};
	
	public static void main(String[] args){
		int i = 0;
		boolean stillSorting = true;
		
		while((i < a.length-1) && stillSorting){
			int count = 0;
			
			for(int j = 0; j<a.length-i-1;j++){
				if(a[j] > a[j+1]){
					int temp = a[j];
					a[j] = a[j+1];
					a[j+1] = temp;
					count++;
				}
			}
			
			if(count <= 1)
				stillSorting = false;
			
			i++;
			
			printArray();
		}
	}
	
	public static void printArray(){
		
		for(int i = 0; i< a.length; i++)
			System.out.print(a[i]+", ");
		
		System.out.println();
	}
}
