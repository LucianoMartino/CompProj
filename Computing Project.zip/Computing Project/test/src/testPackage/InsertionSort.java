package testPackage;

public class InsertionSort {
	
	static int[] aList = {1,2,3,4};
	
	public static void main(String[] args){
		for(int j = 1; j < aList.length; j++){
			int nextItem = aList[j];
			int i = j-1;
			
			while(i >= 0 && aList[i] > nextItem){
				aList[i+1] = aList[i];
				i -= 1;
			}
			
			aList[i+1] = nextItem;
			
			printArray();
		}
		
	}
	
	public static void printArray(){
		for(int i = 0; i< aList.length; i++)
			System.out.print(+aList[i]+", ");
		
		System.out.println();
	}
}
