package testPackage;

public class MergeSort {
	public static void main(String[] args){
		int[] list = {5,2,4,7,1,9};
		mergeSort(list);
	}
	public static void mergeSort(int[] mergeList){
		if(mergeList.length > 1){
			int[] leftHalf = new int[(int)mergeList.length/2], rightHalf = new int[(int)mergeList.length/2];
			for(int i = 0; i<mergeList.length;i++){
				if(i <= mergeList.length/2)
					leftHalf[i] = mergeList[i];
				else
					rightHalf[i] = mergeList[i];
			}
			mergeSort(leftHalf);
			mergeSort(leftHalf);
			int i =0, j = 0, k = 0;
			while(i < leftHalf.length && j < rightHalf.length){
				if(leftHalf[i] < rightHalf[j]){
					mergeList[k] = leftHalf[i];
					i += 1;
				}else{
					mergeList[k] = rightHalf[j];
					j += 1;
				}
				k += 1;
			}
			while(i < leftHalf.length){
				mergeList[k] = leftHalf[i];
				i += 1;
				k += 1;
			}
			while(j < rightHalf.length){
				mergeList[k] = rightHalf[j];
				j += 1;
				k += 1;
			}
			System.out.println("Merged sublist " + mergeList);
		}	
	}
}
