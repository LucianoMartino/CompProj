package testPackage;

public class QuickSort {
	
	public static void main(String[] args){
		int[] nums = {34,56,23,81,28,66,35,17,88,37,18,50};
		
		quickSort(nums, 0, 1, nums.length-1);		
		
		for(int i = 0; i < nums.length; i++)
			System.out.print(nums[i] + ", ");
		
	}
	
	public static void quickSort(int[] list, int pivot, int leftPointer, int rightPointer){
		int temp;
		boolean pivotPlaced = false;
		
		if(leftPointer != rightPointer){
			while(!pivotPlaced){
				
				while(list[leftPointer] < list[pivot] && leftPointer < list.length - 1)
					leftPointer += 1;
				
				while(list[rightPointer] > list[pivot] && rightPointer > 0)
					rightPointer -= 1;
				
				if(leftPointer >= rightPointer && rightPointer > 0){
					temp = list[pivot];
					list[pivot] = list[rightPointer];
					list[rightPointer] = temp;
					
					pivotPlaced = true;
					
					quickSort(list, 0, 1, rightPointer-1);
					quickSort(list, leftPointer, leftPointer + 1, list.length-1);
				
				}else if(list[leftPointer] > list[rightPointer]){
					temp = list[leftPointer];
					list[leftPointer] = list[rightPointer];
					list[rightPointer] = temp;
				}
				
			}
			
		}
	}
}